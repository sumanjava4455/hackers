package hackers;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class Detector {
	
	public static boolean findMissingLetters(String str) {

		boolean[] mark = new boolean[26];

		int z = 0;
		for (int i = 0; i < str.length(); i++) {
			if ('a' <= str.charAt(i) && str.charAt(i) <= 'z')
				z = str.charAt(i) - 'a';
			mark[z] = true;
		}
		for (int i = 0; i <= 25; i++)
			if (!mark[i])
				return (false);
		return (true);
	}


	public static void main(String[] args) throws Exception
	{
		
			Scanner s = new Scanner(System.in);
			System.out.println("Enter the string:");
			String string = s.next();
			Boolean d1 = findMissingLetters(string.toLowerCase());
			if(d1==true)
				System.out.println("\""+string+"\""+" is a panagram");
			else
				System.out.println("\""+string+"\""+" is not a panagram");			
		}
	
			

	}




